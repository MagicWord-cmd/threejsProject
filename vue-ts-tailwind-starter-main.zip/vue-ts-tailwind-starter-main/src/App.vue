<script setup lang="ts">
import { World, Cube, LingoEditor } from "lingo3d-vue"
</script>

<template>
  <World>
    <LingoEditor />
    <Cube />
  </World>
</template>